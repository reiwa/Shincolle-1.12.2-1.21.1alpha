package org.trp.shincolle.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import org.trp.shincolle.Shincolle;
import org.trp.shincolle.client.model.ModelHarbourHime;
import org.trp.shincolle.entity.EntityHarbourHime;

public class RendererHarbourHime extends MobRenderer<EntityHarbourHime, ModelHarbourHime<EntityHarbourHime>> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(Shincolle.MODID, "textures/entity/harbour_hime.png");
    private static final float MODEL_SCALE = 0.34f;

    public RendererHarbourHime(EntityRendererProvider.Context context) {
        super(context, new ModelHarbourHime<>(context.bakeLayer(ModelHarbourHime.LAYER_LOCATION)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(EntityHarbourHime entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(EntityHarbourHime entity, PoseStack poseStack, float partialTickTime) {
        float s = LegacyScale.getScale(entity, this.model);
        poseStack.scale(s, s, s);
    }

    @Override
    protected float getFlipDegrees(EntityHarbourHime entity) {
        if (entity.isInDeadPose()) {
            return 0.0F;
        }
        return super.getFlipDegrees(entity);
    }
}
